package com.bandar.masroufi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsExpenseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val text = messages.joinToString(" ") { it.messageBody.orEmpty() }.trim()
        if (text.isBlank() || !ExpenseParser.looksLikeExpense(text)) return
        val amount = ExpenseParser.extractAmount(text) ?: return
        ExpenseStore(context).addAutomaticExpense(amount, text.take(180), "SMS")
    }
}
