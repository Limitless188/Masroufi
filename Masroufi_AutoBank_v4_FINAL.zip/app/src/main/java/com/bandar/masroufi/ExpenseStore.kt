package com.bandar.masroufi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExpenseStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("masroufi", Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    private val dayFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun ensureMonth() {
        val month = monthKey()
        if (prefs.getString("month_key", null) != month) {
            prefs.edit().putString("month_key", month).putString("expenses", "[]").apply()
        }
    }

    fun addAutomaticExpense(amount: Double, note: String, source: String = "تلقائي"): Boolean {
        ensureMonth()
        val now = System.currentTimeMillis()
        val fingerprint = sha256("${ExpenseParser.normalize(note)}|${"%.2f".format(Locale.US, amount)}|${dayFormat.format(Date(now))}")
        val seen = JSONArray(prefs.getString("automatic_fingerprints", "[]"))
        for (i in 0 until seen.length()) if (seen.optString(i) == fingerprint) return false
        seen.put(fingerprint)
        while (seen.length() > 80) seen.remove(0)
        prefs.edit().putString("automatic_fingerprints", seen.toString()).apply()
        addExpense(amount, note, true, source)
        return true
    }

    fun addExpense(amount: Double, note: String, automatic: Boolean = false, source: String = "يدوي", category: String = ExpenseParser.categoryFor(note)) {
        ensureMonth()
        val arr = JSONArray(prefs.getString("expenses", "[]"))
        val item = JSONObject()
            .put("id", System.currentTimeMillis())
            .put("amount", amount)
            .put("note", note)
            .put("automatic", automatic)
            .put("source", source)
            .put("category", category)
            .put("time", dateFormat.format(Date()))
        arr.put(0, item)
        prefs.edit().putString("expenses", arr.toString()).apply()
    }

    fun deleteExpense(id: Long) {
        val old = JSONArray(prefs.getString("expenses", "[]"))
        val out = JSONArray()
        for (i in 0 until old.length()) if (old.getJSONObject(i).optLong("id") != id) out.put(old.getJSONObject(i))
        prefs.edit().putString("expenses", out.toString()).apply()
    }

    fun expenses(): List<Expense> {
        ensureMonth()
        val arr = JSONArray(prefs.getString("expenses", "[]"))
        val list = mutableListOf<Expense>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Expense(
                o.optLong("id"), o.optDouble("amount"), o.optString("note"),
                o.optBoolean("automatic"), o.optString("time"),
                o.optString("source", if (o.optBoolean("automatic")) "تلقائي" else "يدوي"),
                o.optString("category", ExpenseParser.categoryFor(o.optString("note")))
            )
        }
        return list
    }

    fun clearMonth() { prefs.edit().putString("expenses", "[]").apply() }

    fun salary(): Double = prefs.getString("salary", "7247")?.toDoubleOrNull() ?: 7247.0
    fun setSalary(value: Double) { prefs.edit().putString("salary", value.toString()).apply() }

    fun obligations(): LinkedHashMap<String, Double> {
        val defaults = linkedMapOf("قسط 1" to 722.0, "قسط 2" to 343.0, "قسط 3" to 1002.0, "قسط 4" to 787.0, "فاتورة جوالي" to 543.0, "فاتورة جوال زوجتي" to 80.0, "صندوق الوالد" to 300.0)
        val raw = prefs.getString("obligations", null) ?: return defaults
        return try {
            val arr = JSONArray(raw); val map = linkedMapOf<String, Double>()
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); map[o.optString("name")] = o.optDouble("amount") }
            map
        } catch (_: Exception) { defaults }
    }

    fun setObligations(map: Map<String, Double>) {
        val arr = JSONArray(); map.forEach { (name, amount) -> arr.put(JSONObject().put("name", name).put("amount", amount)) }
        prefs.edit().putString("obligations", arr.toString()).apply()
    }

    private fun monthKey() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}

data class Expense(
    val id: Long,
    val amount: Double,
    val note: String,
    val automatic: Boolean,
    val time: String,
    val source: String,
    val category: String
)

object ExpenseParser {
    fun normalize(s: String): String = s.lowercase(Locale("ar")).replace(Regex("\\s+"), " ").trim()

    fun looksLikeExpense(s: String): Boolean {
        val x = normalize(s)
        val expenseWords = listOf("خصم", "شراء", "عملية شراء", "تم خصم", "دفع", "مدفوع", "سداد", "بطاقة", "نقاط البيع", "pos", "purchase", "debit", "payment", "paid", "مشتريات", "فاتورة", "رسوم", "عمولة")
        val incomeWords = listOf("إيداع", "ايداع", "راتب", "تحويل وارد", "دخل", "استرداد", "استرجاع", "refund", "credit")
        return expenseWords.any { x.contains(it) } && incomeWords.none { x.contains(it) } && extractAmount(s) != null
    }

    fun extractAmount(s: String): Double? {
        val normalized = s.map {
            when (it) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'; '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                '٫' -> '.'; '٬' -> ','; else -> it
            }
        }.joinToString("")
        val patterns = listOf(
            Regex("(?i)(?:مبلغ|بقيمة|قيمة|amount|amt|المبلغ)\\s*[:：]?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"),
            Regex("([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:ريال|ر\\.?س|sar|﷼)"),
            Regex("(?:SAR|ريال|ر\\.?س|﷼)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
        )
        for (p in patterns) {
            val m = p.find(normalized) ?: continue
            val n = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (n > 0 && n <= 100000) return n
        }
        return null
    }

    fun categoryFor(s: String): String {
        val x = normalize(s)
        return when {
            listOf("بنزين", "محطة", "fuel", "gas", "petrol").any { x.contains(it) } -> "بنزين"
            listOf("مطعم", "مقهى", "قهوة", "مأكولات", "food", "restaurant", "cafe").any { x.contains(it) } -> "مطاعم"
            listOf("بقالة", "سوبرماركت", "تموينات", "market", "grocery").any { x.contains(it) } -> "مقاضي"
            listOf("فاتورة", "اتصالات", "stc", "mobily", "zain", "جوالي").any { x.contains(it) } -> "فواتير"
            listOf("amazon", "نون", "متجر", "shopping", "شراء").any { x.contains(it) } -> "تسوق"
            listOf("رسوم", "عمولة", "fee", "commission").any { x.contains(it) } -> "رسوم"
            else -> "عام"
        }
    }
}
