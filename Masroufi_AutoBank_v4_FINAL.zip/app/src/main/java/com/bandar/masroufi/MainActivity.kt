package com.bandar.masroufi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var store: ExpenseStore
    private lateinit var remaining: TextView
    private lateinit var summary: TextView
    private lateinit var monthExpenses: TextView
    private lateinit var todayExpenses: TextView
    private lateinit var expenseCount: TextView
    private lateinit var dailyBudget: TextView
    private lateinit var autoStatus: TextView
    private lateinit var expenseList: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var monthLabel: TextView
    private fun money(x: Double) = NumberFormat.getNumberInstance(Locale.US).format(x) + " ريال"

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        store = ExpenseStore(this)
        bindViews()
        findViewById<Button>(R.id.notificationAccess).setOnClickListener { openNotificationSettings() }
        findViewById<Button>(R.id.smsAccess).setOnClickListener { requestSmsPermissions() }
        findViewById<TextView>(R.id.settingsButton).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.addExpense).setOnClickListener { addManual() }
        findViewById<Button>(R.id.resetMonth).setOnClickListener { resetMonth() }
        refresh()
    }

    override fun onResume() { super.onResume(); if (::store.isInitialized) refresh() }

    private fun bindViews() {
        remaining = findViewById(R.id.remaining)
        summary = findViewById(R.id.summary)
        monthExpenses = findViewById(R.id.monthExpenses)
        todayExpenses = findViewById(R.id.todayExpenses)
        expenseCount = findViewById(R.id.expenseCount)
        dailyBudget = findViewById(R.id.dailyBudget)
        autoStatus = findViewById(R.id.autoStatus)
        expenseList = findViewById(R.id.expenseList)
        progress = findViewById(R.id.budgetProgress)
        progressLabel = findViewById(R.id.progressLabel)
        monthLabel = findViewById(R.id.monthLabel)
    }

    private fun refresh() {
        store.ensureMonth()
        val obligations = store.obligations()
        val fixed = obligations.values.sum()
        val salary = store.salary()
        val available = salary - fixed
        val expenses = store.expenses()
        val spent = expenses.sumOf { it.amount }
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
        val todaySpent = expenses.filter { it.time.startsWith(today) }.sumOf { it.amount }
        val left = available - spent
        val daysLeft = Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH) - Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + 1
        val perDay = if (daysLeft > 0) left / daysLeft else left

        remaining.text = money(left)
        summary.text = "الراتب ${money(salary)}  •  الالتزامات ${money(fixed)}"
        monthExpenses.text = money(spent)
        todayExpenses.text = money(todaySpent)
        expenseCount.text = expenses.size.toString()
        dailyBudget.text = if (perDay >= 0) "${money(perDay)} / يوم" else "متجاوز الميزانية"
        val pct = if (available > 0) ((spent / available) * 100).coerceIn(0.0, 100.0).toInt() else 0
        progress.progress = pct
        progressLabel.text = "استخدمت $pct٪ من ميزانية الصرف"
        monthLabel.text = "ميزانية هذا الشهر • ${daysLeft} يوم متبقي"
        updateAutoStatus()
        renderExpenses(expenses)
    }

    private fun renderExpenses(items: List<Expense>) {
        expenseList.removeAllViews()
        if (items.isEmpty()) {
            expenseList.addView(TextView(this).apply { text = "ما فيه مصاريف مسجلة حتى الآن\nأي عملية بنكية جديدة راح تظهر هنا تلقائيًا."; textSize = 15f; setTextColor(0xFF777B8A.toInt()); gravity = Gravity.RIGHT; setPadding(10, 24, 10, 24) })
            return
        }
        items.take(30).forEach { e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 12, 4, 12) }
            val del = TextView(this).apply { text = "حذف"; textSize = 12f; setTextColor(0xFFD13F4F.toInt()); setPadding(10, 8, 8, 8); setOnClickListener { store.deleteExpense(e.id); refresh() } }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            val title = TextView(this).apply { text = e.category + "  •  " + e.note; textSize = 14f; setTextColor(0xFF25283A.toInt()); gravity = Gravity.RIGHT; maxLines = 2 }
            val meta = TextView(this).apply { text = "${e.time}  •  ${e.source}"; textSize = 11f; setTextColor(0xFF8A8D99.toInt()); gravity = Gravity.RIGHT; setPadding(0, 3, 0, 0) }
            details.addView(title); details.addView(meta)
            val amount = TextView(this).apply { text = money(e.amount); textSize = 16f; setTextColor(0xFF171A2B.toInt()); gravity = Gravity.LEFT; setPadding(8, 0, 8, 0) }
            row.addView(del, LinearLayout.LayoutParams(55, -2)); row.addView(details, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(amount, LinearLayout.LayoutParams(112, -2))
            expenseList.addView(row)
            expenseList.addView(android.view.View(this).apply { setBackgroundColor(0xFFE7E8ED.toInt()) }, LinearLayout.LayoutParams(-1, 1))
        }
    }

    private fun addManual() {
        val amountBox = findViewById<TextInputEditText>(R.id.expenseAmount)
        val noteBox = findViewById<TextInputEditText>(R.id.expenseNote)
        val amount = amountBox.text?.toString()?.replace(",", "")?.replace("٫", ".")?.toDoubleOrNull()
        if (amount == null || amount <= 0) { amountBox.error = "اكتب مبلغ صحيح"; return }
        val note = noteBox.text?.toString()?.trim().orEmpty().ifBlank { "مصروف يدوي" }
        store.addExpense(amount, note)
        amountBox.text = null; noteBox.text = null; refresh()
        Toast.makeText(this, "تم تسجيل المصروف • ${ExpenseParser.categoryFor(note)}", Toast.LENGTH_SHORT).show()
    }

    private fun updateAutoStatus() {
        val notif = try { android.service.notification.NotificationListenerService.getEnabledListenerPackages(this).contains(packageName) } catch (_: Exception) { false }
        val sms = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        autoStatus.text = when {
            notif && sms -> "🟢 شغال بالكامل: إشعارات البنك + SMS\nأي عملية شراء قابلة للقراءة تُسجّل تلقائيًا."
            notif -> "🟡 شغال عبر إشعارات البنك فقط\nفعّل SMS أيضًا لزيادة التغطية."
            sms -> "🟡 شغال عبر SMS فقط\nفعّل إشعارات البنك لزيادة التغطية."
            else -> "🔴 التسجيل التلقائي غير مفعّل\nفعّل أحد الخيارين بالأسفل."
        }
    }

    private fun openNotificationSettings() {
        try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private fun requestSmsPermissions() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 100)
    }

    private fun showSettings() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 4) }
        val salaryBox = EditText(this).apply { hint = "الراتب الشهري"; inputType = 2 or 8192; setText(store.salary().toString()); gravity = Gravity.RIGHT }
        container.addView(salaryBox)
        val names = mutableListOf<EditText>(); val amounts = mutableListOf<EditText>()
        store.obligations().forEach { (name, amount) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val n = EditText(this).apply { hint = "اسم الالتزام"; setText(name); gravity = Gravity.RIGHT }
            val a = EditText(this).apply { hint = "المبلغ"; setText(amount.toString()); inputType = 2 or 8192; gravity = Gravity.RIGHT }
            names += n; amounts += a
            row.addView(n, LinearLayout.LayoutParams(0, -2, 1.25f)); row.addView(a, LinearLayout.LayoutParams(0, -2, 1f)); container.addView(row)
        }
        MaterialAlertDialogBuilder(this).setTitle("إعدادات مصروفي").setMessage("عدّل الراتب والالتزامات. البيانات محفوظة على جهازك.").setView(container).setNegativeButton("إلغاء", null).setPositiveButton("حفظ") { _, _ ->
            store.setSalary(salaryBox.text.toString().toDoubleOrNull() ?: store.salary())
            val map = linkedMapOf<String, Double>()
            for (i in names.indices) { val n = names[i].text.toString().trim(); val a = amounts[i].text.toString().toDoubleOrNull(); if (n.isNotBlank() && a != null && a >= 0) map[n] = a }
            if (map.isNotEmpty()) store.setObligations(map)
            refresh(); Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun resetMonth() {
        MaterialAlertDialogBuilder(this).setTitle("تصفير مصاريف الشهر؟").setMessage("سيتم حذف سجل مصاريف الشهر من الجهاز. لا يمكن التراجع.").setNegativeButton("إلغاء", null).setPositiveButton("تصفير") { _, _ -> store.clearMonth(); refresh() }.show()
    }
}
