package com.bandar.masroufi

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val salary = 7247.0
    private val obligations = linkedMapOf(
        "قسط 1" to 722.0, "قسط 2" to 343.0, "قسط 3" to 1002.0, "قسط 4" to 787.0,
        "فاتورة جوالي" to 543.0, "فاتورة جوال زوجتي" to 80.0, "صندوق الوالد" to 300.0
    )
    private val prefs by lazy { getSharedPreferences("masroufi", MODE_PRIVATE) }
    private var spent = 0.0
    private lateinit var remaining: TextView
    private lateinit var summary: TextView
    private lateinit var monthExpenses: TextView
    private lateinit var dailyHint: TextView
    private fun money(x: Double) = NumberFormat.getNumberInstance(Locale.US).format(x) + " ريال"

    override fun onCreate(state: Bundle?) {
        super.onCreate(state); setContentView(R.layout.activity_main)
        remaining=findViewById(R.id.remaining); summary=findViewById(R.id.summary)
        monthExpenses=findViewById(R.id.monthExpenses); dailyHint=findViewById(R.id.dailyHint)
        spent=prefs.getFloat("spent",0f).toDouble()
        val box=findViewById<LinearLayout>(R.id.obligations)
        obligations.forEach { (n,a) -> box.addView(TextView(this).apply {
            text="$n    ${money(a)}"; textSize=16f; gravity=android.view.Gravity.RIGHT
            setTextColor(0xFF374151.toInt()); setPadding(6,12,6,12)
        })}
        findViewById<Button>(R.id.addExpense).setOnClickListener {
            val e=findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.expenseAmount)
            val n=findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.expenseNote)
            val a=e.text?.toString()?.toDoubleOrNull()
            if(a==null || a<=0){Toast.makeText(this,"اكتب مبلغ صحيح",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            spent+=a; prefs.edit().putFloat("spent",spent.toFloat()).apply()
            e.text=null;n.text=null;update();Toast.makeText(this,"تم تسجيل المصروف",Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.resetMonth).setOnClickListener {
            MaterialAlertDialogBuilder(this).setTitle("تصفير الشهر؟").setMessage("سيتم حذف إجمالي المصاريف المسجلة.")
            .setNegativeButton("إلغاء",null).setPositiveButton("تصفير"){_,_->spent=0.0;prefs.edit().putFloat("spent",0f).apply();update()}.show()
        }
        update()
    }
    private fun update(){
        val fixed=obligations.values.sum(); val available=salary-fixed; val left=available-spent
        remaining.text=money(left); summary.text="الراتب ${money(salary)} • الالتزامات ${money(fixed)}"
        monthExpenses.text="إجمالي مصاريف الشهر: ${money(spent)}"
        dailyHint.text="المتاح قبل المصاريف اليومية: ${money(available)}"
    }
}
