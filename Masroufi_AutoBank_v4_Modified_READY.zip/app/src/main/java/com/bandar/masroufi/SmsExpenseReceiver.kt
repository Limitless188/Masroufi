package com.bandar.masroufi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.util.Locale

class SmsExpenseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val text = messages.joinToString(" ") { it.messageBody.orEmpty() }.trim()
        if (text.isBlank()) return
        if (!ExpenseParser.looksLikeExpense(text)) return
        val amount = ExpenseParser.extractAmount(text) ?: return
        ExpenseStore(context).addAutomaticExpense(amount, "رسالة بنك: ${text.replace("|", " ").take(140)}")
    }
}

object ExpenseParser {
    fun normalize(s: String): String = s.lowercase(Locale("ar")).replace(Regex("\\s+"), " ").trim()

    fun looksLikeExpense(s: String): Boolean {
        val x = normalize(s)
        val expenseWords = listOf("خصم", "شراء", "عملية شراء", "تم خصم", "دفع", "مدفوع", "سداد", "بطاقة", "نقاط البيع", "pos", "purchase", "debit", "payment", "paid", "sar", "ريال")
        val incomeWords = listOf("إيداع", "ايداع", "راتب", "تحويل وارد", "دخل")
        return expenseWords.any { x.contains(it) } && incomeWords.none { x.contains(it) } && extractAmount(s) != null
    }

    fun extractAmount(s: String): Double? {
        val arabicDigits = s.map {
            when (it) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'; '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                '٫' -> '.'; '٬' -> ','; else -> it
            }
        }.joinToString("")
        val patterns = listOf(
            Regex("(?i)(?:مبلغ|بقيمة|قيمة|amount)\\s*[:：]?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"),
            Regex("([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:ريال|ر\\.?س|sar)"),
            Regex("(?:SAR|ريال|ر\\.?س)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
        )
        for (p in patterns) {
            val m = p.find(arabicDigits) ?: continue
            val n = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (n > 0 && n <= 100000) return n
        }
        return null
    }
}
