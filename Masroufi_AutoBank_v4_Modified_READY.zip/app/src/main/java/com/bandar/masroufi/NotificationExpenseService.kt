package com.bandar.masroufi

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationExpenseService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val full = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(" — ")
        if (!ExpenseParser.looksLikeExpense(full)) return
        val amount = ExpenseParser.extractAmount(full) ?: return
        ExpenseStore(this).addAutomaticExpense(amount, "إشعار بنك: ${full.replace("|", " ").take(140)}")
    }
}
