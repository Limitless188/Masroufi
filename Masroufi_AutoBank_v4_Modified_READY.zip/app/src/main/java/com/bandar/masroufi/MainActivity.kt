package com.bandar.masroufi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var store: ExpenseStore
    private lateinit var remaining: TextView
    private lateinit var summary: TextView
    private lateinit var monthExpenses: TextView
    private lateinit var expenseCount: TextView
    private lateinit var dailyHint: TextView
    private lateinit var autoStatus: TextView
    private lateinit var expenseList: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var progressLabel: TextView
    private lateinit var monthLabel: TextView
    private fun money(x: Double) = NumberFormat.getNumberInstance(Locale.US).format(x) + " ريال"

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        store = ExpenseStore(this)
        bindViews()
        findViewById<Button>(R.id.notificationAccess).setOnClickListener { openNotificationSettings() }
        findViewById<Button>(R.id.smsAccess).setOnClickListener { requestSmsPermissions() }
        findViewById<TextView>(R.id.settingsButton).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.addExpense).setOnClickListener { addManual() }
        findViewById<Button>(R.id.resetMonth).setOnClickListener { resetMonth() }
        refresh()
    }

    override fun onResume() { super.onResume(); if (::store.isInitialized) refresh() }

    private fun bindViews() {
        remaining = findViewById(R.id.remaining); summary = findViewById(R.id.summary); monthExpenses = findViewById(R.id.monthExpenses)
        expenseCount = findViewById(R.id.expenseCount); dailyHint = findViewById(R.id.dailyHint); autoStatus = findViewById(R.id.autoStatus)
        expenseList = findViewById(R.id.expenseList); progress = findViewById(R.id.budgetProgress); progressLabel = findViewById(R.id.progressLabel); monthLabel = findViewById(R.id.monthLabel)
    }

    private fun refresh() {
        store.ensureMonth()
        val obligations = store.obligations()
        val fixed = obligations.values.sum()
        val salary = store.salary()
        val available = salary - fixed
        val expenses = store.expenses()
        val spent = expenses.sumOf { it.amount }
        val left = available - spent
        remaining.text = money(left)
        summary.text = "الراتب ${money(salary)}  •  الالتزامات ${money(fixed)}"
        monthExpenses.text = money(spent)
        expenseCount.text = expenses.size.toString()
        dailyHint.text = if (left > 0) "متوسط المتاح يوميًا حتى نهاية الشهر يتغير تلقائيًا مع كل مصروف." else "تنبيه: تجاوزت ميزانية الصرف المتاحة لهذا الشهر."
        val pct = if (available > 0) ((spent / available) * 100).coerceIn(0.0, 100.0).toInt() else 0
        progress.progress = pct
        progressLabel.text = "استخدمت $pct٪ من ميزانية الصرف"
        monthLabel.text = "ميزانية هذا الشهر • راتب ${money(salary)}"
        updateAutoStatus()
        renderExpenses(expenses)
    }

    private fun renderExpenses(items: List<Expense>) {
        expenseList.removeAllViews()
        if (items.isEmpty()) {
            val empty = TextView(this).apply { text = "ما فيه مصاريف مسجلة حتى الآن"; textSize = 15f; setTextColor(0xFF777B8A.toInt()); gravity = Gravity.RIGHT; setPadding(10, 20, 10, 20) }
            expenseList.addView(empty); return
        }
        items.take(20).forEach { e ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(6, 13, 6, 13) }
            val del = TextView(this).apply { text = "حذف"; textSize = 12f; setTextColor(0xFFD13F4F.toInt()); setPadding(12, 8, 8, 8); setOnClickListener { store.deleteExpense(e.id); refresh() } }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            val title = TextView(this).apply { text = e.note.ifBlank { "مصروف" }; textSize = 14f; setTextColor(0xFF343746.toInt()); gravity = Gravity.RIGHT; maxLines = 2 }
            val meta = TextView(this).apply { text = "${e.time} • ${if (e.automatic) "تلقائي" else "يدوي"}"; textSize = 11f; setTextColor(0xFF8A8D99.toInt()); gravity = Gravity.RIGHT }
            details.addView(title); details.addView(meta)
            val amount = TextView(this).apply { text = money(e.amount); textSize = 16f; setTextColor(0xFF171A2B.toInt()); gravity = Gravity.LEFT; setPadding(8, 0, 8, 0) }
            row.addView(del, LinearLayout.LayoutParams(55, LinearLayout.LayoutParams.WRAP_CONTENT)); row.addView(details, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); row.addView(amount, LinearLayout.LayoutParams(105, LinearLayout.LayoutParams.WRAP_CONTENT))
            expenseList.addView(row)
            val line = View(this).apply { setBackgroundColor(0xFFE7E8ED.toInt()) }
            expenseList.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun addManual() {
        val amountBox = findViewById<TextInputEditText>(R.id.expenseAmount); val noteBox = findViewById<TextInputEditText>(R.id.expenseNote)
        val amount = amountBox.text?.toString()?.replace(",", "")?.toDoubleOrNull()
        if (amount == null || amount <= 0) { Toast.makeText(this, "اكتب مبلغ صحيح", Toast.LENGTH_SHORT).show(); return }
        store.addExpense(amount, noteBox.text?.toString().orEmpty())
        amountBox.text = null; noteBox.text = null; refresh(); Toast.makeText(this, "تم تسجيل المصروف", Toast.LENGTH_SHORT).show()
    }

    private fun updateAutoStatus() {
        val notif = try { android.service.notification.NotificationListenerService.getEnabledListenerPackages(this).contains(packageName) } catch (_: Exception) { false }
        val sms = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        autoStatus.text = when {
            notif && sms -> "🟢 التلقائي مفعّل: الإشعارات + رسائل SMS"
            notif -> "🟢 التلقائي مفعّل للإشعارات البنكية"
            sms -> "🟢 التلقائي مفعّل لرسائل SMS"
            else -> "🔴 التسجيل التلقائي غير مفعّل بعد"
        }
    }

    private fun openNotificationSettings() { try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) } }
    private fun requestSmsPermissions() {
        val permissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        ActivityCompat.requestPermissions(this, permissions, 100)
    }

    private fun showSettings() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 4, 20, 4) }
        val salaryBox = EditText(this).apply { hint = "الراتب الشهري"; inputType = 2 or 8192; setText(store.salary().toString()); gravity = Gravity.RIGHT }
        container.addView(salaryBox)
        val names = mutableListOf<EditText>(); val amounts = mutableListOf<EditText>()
        store.obligations().forEach { (name, amount) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val n = EditText(this).apply { hint = "اسم الالتزام"; setText(name); gravity = Gravity.RIGHT }
            val a = EditText(this).apply { hint = "المبلغ"; setText(amount.toString()); inputType = 2 or 8192; gravity = Gravity.RIGHT }
            names += n; amounts += a
            row.addView(n, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f)); row.addView(a, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)); container.addView(row)
        }
        MaterialAlertDialogBuilder(this).setTitle("إعدادات الميزانية").setMessage("عدّل راتبك والتزاماتك، وسيُعاد حساب المتبقي تلقائيًا.").setView(container).setNegativeButton("إلغاء", null).setPositiveButton("حفظ") { _, _ ->
            store.setSalary(salaryBox.text.toString().toDoubleOrNull() ?: store.salary())
            val map = linkedMapOf<String, Double>(); for (i in names.indices) { val n = names[i].text.toString().trim(); val a = amounts[i].text.toString().toDoubleOrNull(); if (n.isNotBlank() && a != null && a >= 0) map[n] = a }; if (map.isNotEmpty()) store.setObligations(map); refresh(); Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun resetMonth() { MaterialAlertDialogBuilder(this).setTitle("تصفير الشهر؟").setMessage("سيتم حذف جميع المصاريف المسجلة لهذا الشهر.").setNegativeButton("إلغاء", null).setPositiveButton("تصفير") { _, _ -> store.clearMonth(); refresh() }.show() }
}
