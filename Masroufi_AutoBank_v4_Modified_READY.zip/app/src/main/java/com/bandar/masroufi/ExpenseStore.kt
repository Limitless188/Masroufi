package com.bandar.masroufi

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExpenseStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("masroufi", Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun ensureMonth() {
        val month = monthKey()
        if (prefs.getString("month_key", null) != month) {
            prefs.edit().putString("month_key", month).putString("expenses", "[]").apply()
        }
    }

    fun addAutomaticExpense(amount: Double, note: String): Boolean {
        ensureMonth()
        val fingerprint = ExpenseParser.normalize(note) + "|" + String.format(Locale.US, "%.2f", amount)
        val lastFingerprint = prefs.getString("last_fingerprint", "")
        if (fingerprint == lastFingerprint) return false
        prefs.edit().putString("last_fingerprint", fingerprint).apply()
        addExpense(amount, note, true)
        return true
    }

    fun addExpense(amount: Double, note: String, automatic: Boolean = false) {
        ensureMonth()
        val arr = JSONArray(prefs.getString("expenses", "[]"))
        val item = JSONObject()
            .put("id", System.currentTimeMillis())
            .put("amount", amount)
            .put("note", note)
            .put("automatic", automatic)
            .put("time", dateFormat.format(Date()))
        arr.put(0, item)
        prefs.edit().putString("expenses", arr.toString()).apply()
    }

    fun deleteExpense(id: Long) {
        val old = JSONArray(prefs.getString("expenses", "[]"))
        val out = JSONArray()
        for (i in 0 until old.length()) if (old.getJSONObject(i).optLong("id") != id) out.put(old.getJSONObject(i))
        prefs.edit().putString("expenses", out.toString()).apply()
    }

    fun expenses(): List<Expense> {
        ensureMonth()
        val arr = JSONArray(prefs.getString("expenses", "[]"))
        val list = mutableListOf<Expense>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Expense(o.optLong("id"), o.optDouble("amount"), o.optString("note"), o.optBoolean("automatic"), o.optString("time"))
        }
        return list
    }

    fun clearMonth() { prefs.edit().putString("expenses", "[]").apply() }

    fun salary(): Double = prefs.getString("salary", "7247")?.toDoubleOrNull() ?: 7247.0
    fun setSalary(value: Double) { prefs.edit().putString("salary", value.toString()).apply() }

    fun obligations(): LinkedHashMap<String, Double> {
        val defaults = linkedMapOf("قسط 1" to 722.0, "قسط 2" to 343.0, "قسط 3" to 1002.0, "قسط 4" to 787.0, "فاتورة جوالي" to 543.0, "فاتورة جوال زوجتي" to 80.0, "صندوق الوالد" to 300.0)
        val raw = prefs.getString("obligations", null) ?: return defaults
        val arr = JSONArray(raw)
        val map = linkedMapOf<String, Double>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            map[o.optString("name")] = o.optDouble("amount")
        }
        return map
    }

    fun setObligations(map: Map<String, Double>) {
        val arr = JSONArray()
        map.forEach { (name, amount) -> arr.put(JSONObject().put("name", name).put("amount", amount)) }
        prefs.edit().putString("obligations", arr.toString()).apply()
    }

    private fun monthKey() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
}

data class Expense(val id: Long, val amount: Double, val note: String, val automatic: Boolean, val time: String)
