package com.bandar.masroufi

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val salary = 7247.0
    private val obligations = linkedMapOf(
        "قسط 1" to 722.0, "قسط 2" to 343.0, "قسط 3" to 1002.0, "قسط 4" to 787.0,
        "فاتورة جوالي" to 543.0, "فاتورة جوال زوجتي" to 80.0, "صندوق الوالد" to 300.0
    )
    private val prefs by lazy { getSharedPreferences("masroufi", MODE_PRIVATE) }
    private var spent = 0.0
    private lateinit var remaining: TextView
    private lateinit var summary: TextView
    private lateinit var monthExpenses: TextView
    private lateinit var dailyHint: TextView
    private lateinit var autoStatus: TextView
    private fun money(x: Double) = NumberFormat.getNumberInstance(Locale.US).format(x) + " ريال"

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        remaining = findViewById(R.id.remaining)
        summary = findViewById(R.id.summary)
        monthExpenses = findViewById(R.id.monthExpenses)
        dailyHint = findViewById(R.id.dailyHint)
        autoStatus = findViewById(R.id.autoStatus)
        ensureMonth()

        val box = findViewById<LinearLayout>(R.id.obligations)
        obligations.forEach { (name, amount) ->
            box.addView(TextView(this).apply {
                text = "$name    ${money(amount)}"
                textSize = 16f
                gravity = Gravity.RIGHT
                setTextColor(0xFF374151.toInt())
                setPadding(6, 12, 6, 12)
            })
        }

        findViewById<Button>(R.id.notificationAccess).setOnClickListener {
            try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        findViewById<Button>(R.id.addExpense).setOnClickListener {
            val amountBox = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.expenseAmount)
            val noteBox = findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.expenseNote)
            val amount = amountBox.text?.toString()?.replace(",", "")?.toDoubleOrNull()
            if (amount == null || amount <= 0) {
                Toast.makeText(this, "اكتب مبلغ صحيح", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            addExpense(amount, noteBox.text?.toString().orEmpty())
            amountBox.text = null; noteBox.text = null
            update()
            Toast.makeText(this, "تم تسجيل المصروف", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.resetMonth).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("تصفير الشهر؟")
                .setMessage("سيتم حذف المصاريف المسجلة لهذا الشهر.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("تصفير") { _, _ ->
                    spent = 0.0
                    prefs.edit().putFloat("spent", 0f).putString("month_key", monthKey()).putString("history", "").apply()
                    update()
                }.show()
        }
        update()
    }

    override fun onResume() {
        super.onResume()
        ensureMonth()
        if (::autoStatus.isInitialized) updateAutoStatus()
        if (::remaining.isInitialized) update()
    }

    private fun ensureMonth() {
        val month = monthKey()
        if (prefs.getString("month_key", null) != month) {
            prefs.edit().putString("month_key", month).putFloat("spent", 0f).putString("history", "").apply()
        }
        spent = prefs.getFloat("spent", 0f).toDouble()
    }

    private fun monthKey() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

    private fun addExpense(amount: Double, note: String) {
        spent += amount
        val line = "${System.currentTimeMillis()}|$amount|${note.replace("|", " ").take(120)}"
        val history = prefs.getString("history", "").orEmpty()
        prefs.edit().putFloat("spent", spent.toFloat()).putString("history", (line + if (history.isBlank()) "" else "\n$history").take(12000)).apply()
    }

    private fun update() {
        ensureMonth()
        val fixed = obligations.values.sum()
        val available = salary - fixed
        val left = available - spent
        remaining.text = money(left)
        summary.text = "الراتب ${money(salary)} • الالتزامات ${money(fixed)}"
        monthExpenses.text = "إجمالي مصاريف الشهر: ${money(spent)}"
        dailyHint.text = "المتاح قبل المصاريف اليومية: ${money(available)}"
        updateAutoStatus()
    }

    private fun updateAutoStatus() {
        autoStatus.text = if (isNotificationAccessEnabled())
            "🟢 التسجيل التلقائي مفعّل — أي عملية شراء في إشعارات البنك تُسجّل تلقائياً"
        else
            "🔴 التسجيل التلقائي غير مفعّل — اضغط الزر وفعّل وصول الإشعارات"
    }

    private fun isNotificationAccessEnabled(): Boolean = try {
        android.service.notification.NotificationListenerService.getEnabledListenerPackages(this).contains(packageName)
    } catch (_: Exception) { false }
}
