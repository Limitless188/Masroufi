package com.bandar.masroufi

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class NotificationExpenseService : NotificationListenerService() {
    private val prefs by lazy { getSharedPreferences("masroufi", MODE_PRIVATE) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val full = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(" — ")
        if (full.isBlank() || !looksLikeExpense(full)) return

        val amount = extractAmount(full) ?: return
        if (amount <= 0.0 || amount > 100_000.0) return

        val fingerprint = "${sbn.packageName}|${normalize(full)}|${(System.currentTimeMillis() / 60_000L)}"
        val last = prefs.getString("last_auto_fingerprint", "")
        if (fingerprint == last) return
        prefs.edit().putString("last_auto_fingerprint", fingerprint).apply()

        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        val savedMonth = prefs.getString("month_key", month)
        if (savedMonth != month) {
            prefs.edit().putString("month_key", month).putFloat("spent", 0f).apply()
        }
        val spent = prefs.getFloat("spent", 0f).toDouble() + amount
        prefs.edit().putFloat("spent", spent.toFloat()).apply()

        val history = prefs.getString("history", "")
        val safeNote = normalize(full).take(120).replace("|", " ")
        val line = "${System.currentTimeMillis()}|${amount}|$safeNote"
        prefs.edit().putString("history", (line + if (history.isNullOrBlank()) "" else "\n$history").take(12000)).apply()
    }

    private fun looksLikeExpense(s: String): Boolean {
        val x = normalize(s)
        val keywords = listOf(
            "خصم", "شراء", "عملية شراء", "تم خصم", "دفع", "مدفوع", "سداد",
            "بطاقة", "نقاط البيع", "pos", "purchase", "debit", "payment", "paid", "sar", "ريال"
        )
        return keywords.any { x.contains(it) } && extractAmount(s) != null
    }

    private fun extractAmount(s: String): Double? {
        val arabicDigits = s.map {
            when (it) {
                '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
                '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                '٫' -> '.'; '٬' -> ','; else -> it
            }
        }.joinToString("")
        val patterns = listOf(
            Regex("(?i)(?:مبلغ|بقيمة|قيمة|amount)\\s*[:：]?\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"),
            Regex("([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:ريال|ر\\.?س|sar)"),
            Regex("(?:SAR|ريال|ر\\.?س)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)")
        )
        for (p in patterns) {
            val m = p.find(arabicDigits) ?: continue
            val n = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: continue
            if (n > 0) return n
        }
        return null
    }

    private fun normalize(s: String): String = s
        .lowercase(Locale("ar"))
        .replace(Regex("\\s+"), " ")
        .trim()
}
